# 🚀 Panel de Control WEB2

Una aplicación de escritorio para iniciar y controlar los servidores Backend y Frontend de WEB2 de manera fácil y visual.

## ✨ Características

- 🖥️ **Control de Backend**: Inicia/detiene el servidor Node.js (puerto 3001)
- 🎨 **Control de Frontend**: Inicia/detiene el servidor Vite (puerto 5174)  
- 📊 **Monitoreo en tiempo real**: Indicadores de estado visual (🟢/🔴)
- 📋 **Log integrado**: Historial de eventos con timestamps
- 🌐 **Apertura automática**: Botón para abrir la aplicación en el navegador
- 🔄 **Reinicio inteligente**: Reinicia ambos servicios de forma segura
- ℹ️ **Ayuda integrada**: Troubleshooting y URLs importantes

## 🛠️ Instalación y Uso

### Opción 1: Ejecutar directamente con Python
```bash
# Instalar dependencias
pip install -r requirements.txt

# Ejecutar aplicación
python panel_control.py
```

### Opción 2: Compilar a ejecutable (.exe)
```bash
# Ejecutar script de compilación
build.bat
```

Esto creará `Panel-Control-WEB2.exe` en la carpeta `dist/`

## 🎯 Cómo usar

1. **Iniciar Backend**: Click en "🚀 Iniciar Backend"
2. **Esperar confirmación**: Hasta ver "Backend listo en puerto 3001"
3. **Iniciar Frontend**: Click en "🚀 Iniciar Frontend" 
4. **Esperar confirmación**: Hasta ver "Frontend listo en puerto 5174"
5. **Abrir aplicación**: Click en "🌐 Abrir Aplicación"

## 🔧 Requisitos

- **Python 3.7+** (solo para ejecución directa)
- **Node.js** (para ejecutar los servidores)
- **npm** (para el frontend)

## 📋 Dependencias Python

- `psutil`: Control de procesos del sistema
- `requests`: Verificación de estado de puertos
- `tkinter`: Interfaz gráfica (incluido en Python)

## 🌐 URLs

- **Frontend**: http://localhost:5174
- **Backend**: http://localhost:3001  
- **Health Check**: http://localhost:3001/health

## 🚨 Solución de problemas

### Backend no inicia
- Verificar que Node.js esté instalado
- Verificar que el puerto 3001 esté libre
- Revisar el log de eventos para errores específicos

### Frontend no inicia  
- Verificar que npm esté instalado
- Ejecutar `npm install` en la carpeta dashboard
- Verificar que el puerto 5174 esté libre

### Procesos no se detienen
- Usar el botón "🔄 Reiniciar Todo"
- Cerrar manualmente las terminales de Node.js
- Reiniciar la aplicación del panel

## 📁 Estructura de archivos

```
panel-control-web2/
├── panel_control.py      # Aplicación principal
├── requirements.txt      # Dependencias Python
├── build.bat            # Script de compilación
├── README.md            # Este archivo
└── dist/                # Ejecutable compilado (después de build)
    └── Panel-Control-WEB2.exe
```

## 🎨 Interfaz

```
╔══════════════════════════════════════════════════════════════╗
║                    PANEL CONTROL WEB2                       ║
╠══════════════════════════════════════════════════════════════╣
║  BACKEND (Puerto 3001)           FRONTEND (Puerto 5174)     ║
║  [🚀 Iniciar] [🛑 Detener]      [🚀 Iniciar] [🛑 Detener]   ║
║  Estado: 🟢 Corriendo            Estado: 🔴 Detenido        ║
║                                                              ║
║  [🌐 Abrir Aplicación]  [🔄 Reiniciar Todo]  [ℹ️ Ayuda]    ║
║                                                              ║
║  ┌─── Log de Estado ────────────────────────────────────┐   ║
║  │ [12:34:56] Backend iniciado en puerto 3001          │   ║
║  │ [12:35:02] Frontend iniciado en puerto 5174         │   ║
║  │ [12:35:05] ✅ Aplicación lista!                     │   ║
║  └─────────────────────────────────────────────────────┘   ║
╚══════════════════════════════════════════════════════════════╝
```

---

**Nota**: Esta aplicación está configurada para no subirse al repositorio remoto (incluida en .gitignore)
