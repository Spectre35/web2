
import subprocess
import sys
import os

def install_dependencies():
    """Instalar dependencias automáticamente"""
    print("🚀 Panel de Control WEB2 - Instalador")
    print("=" * 50)
    print()

    try:
        # Verificar Python
        print("✅ Verificando Python...")
        python_version = sys.version
        print(f"   Python {python_version.split()[0]} detectado")
        print()

        # Instalar dependencias
        print("📦 Instalando dependencias...")

        dependencies = ["psutil==5.9.5", "requests==2.31.0"]

        for dep in dependencies:
            print(f"   Instalando {dep}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", dep])

        print()
        print("✅ ¡Dependencias instaladas correctamente!")
        print()
        print("🚀 Iniciando Panel de Control...")
        print()

        # Importar y ejecutar la aplicación
        from panel_control import main
        main()

    except ImportError as e:
        print(f"❌ Error de importación: {e}")
        print("💡 Intenta ejecutar: pip install -r requirements.txt")
        input("Presiona Enter para continuar...")

    except subprocess.CalledProcessError as e:
        print(f"❌ Error al instalar dependencias: {e}")
        print("💡 Verifica tu conexión a internet y permisos")
        input("Presiona Enter para continuar...")

    except Exception as e:
        print(f"❌ Error inesperado: {e}")
        input("Presiona Enter para continuar...")

if __name__ == "__main__":
    install_dependencies()
