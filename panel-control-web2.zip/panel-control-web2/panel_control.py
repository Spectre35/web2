#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Panel de Control WEB2 - Versión Mejorada
Aplicación para iniciar/detener Backend y Frontend localmente
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import subprocess
import threading
import time
import webbrowser
import os
import signal
import psutil
import requests
from datetime import datetime
import json

class PanelControlWEB2:
    def __init__(self, root):
        self.root = root
        self.root.title("🚀 Panel de Control WEB2 - Versión Optimizada")
        self.root.geometry("900x600")
        self.root.configure(bg='#2b2b2b')

        # Rutas del proyecto - usando rutas relativas
        # Obtener la ruta del directorio donde está el script
        script_dir = os.path.dirname(os.path.abspath(__file__))
        # Subir un nivel para llegar a la raíz del proyecto
        self.project_path = os.path.dirname(script_dir)
        self.dashboard_path = os.path.join(self.project_path, "dashboard")
        self.ocr_path = os.path.join(self.project_path, "ocr-system")

        # Procesos
        self.backend_process = None
        self.frontend_process = None
        self.ocr_process = None

        # Variables de estado
        self.backend_status = tk.StringVar(value="🔴 Detectando...")
        self.frontend_status = tk.StringVar(value="🔴 Detectando...")
        self.ocr_status = tk.StringVar(value="🔴 Detectando...")
        self.backend_pid = tk.StringVar(value="PID: N/A")
        self.frontend_pid = tk.StringVar(value="PID: N/A")
        self.ocr_pid = tk.StringVar(value="PID: N/A")

        # Configurar interfaz
        self.setup_ui()

        # Validar rutas
        self.validate_paths()

        # Verificar prerequisitos
        self.check_prerequisites()

        # Detectar procesos existentes al iniciar
        self.detect_existing_processes()

        # Iniciar monitoreo
        self.start_monitoring()

    def detect_existing_processes(self):
        """Detectar procesos existentes al iniciar"""
        try:
            # Detectar backend (Node.js en puerto 3001)
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if proc.info['name'] == 'node.exe':
                        cmdline = ' '.join(proc.info['cmdline']) if proc.info['cmdline'] else ''
                        if 'server.js' in cmdline and self.project_path in cmdline and 'ocr-system' not in cmdline:
                            self.backend_process = proc
                            self.log(f"🔍 Backend detectado (PID: {proc.pid})")
                            break
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            # Detectar frontend (npm/vite en puerto 5174)
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if proc.info['name'] in ['node.exe', 'npm.cmd']:
                        cmdline = ' '.join(proc.info['cmdline']) if proc.info['cmdline'] else ''
                        if ('vite' in cmdline or 'npm run dev' in cmdline) and 'dashboard' in cmdline:
                            self.frontend_process = proc
                            self.log(f"🔍 Frontend detectado (PID: {proc.pid})")
                            break
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            # Detectar sistema OCR (Node.js en puerto 3002)
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if proc.info['name'] == 'node.exe':
                        cmdline = ' '.join(proc.info['cmdline']) if proc.info['cmdline'] else ''
                        if 'server.js' in cmdline and 'ocr-system' in cmdline:
                            self.ocr_process = proc
                            self.log(f"🔍 Sistema OCR detectado (PID: {proc.pid})")
                            break
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

        except Exception as e:
            self.log(f"⚠️ Error detectando procesos: {str(e)}")

    def validate_paths(self):
        """Validar que las rutas existan"""
        paths_to_check = [
            (self.project_path, "Proyecto principal"),
            (self.dashboard_path, "Dashboard"),
            (self.ocr_path, "Sistema OCR")
        ]

        for path, name in paths_to_check:
            if not os.path.exists(path):
                messagebox.showerror(
                    "Error de configuración",
                    f"❌ No se encontró la ruta de {name}:\n{path}\n\n"
                    "Por favor, asegúrate de que el Panel de Control esté en la carpeta correcta."
                )
                self.root.quit()
                return False
        return True

    def check_prerequisites(self):
        """Verificar que Node.js y npm estén instalados"""
        try:
            # Verificar Node.js
            node_result = subprocess.run(["node", "--version"], capture_output=True, text=True, shell=True)
            if node_result.returncode == 0:
                node_version = node_result.stdout.strip()
                self.log(f"✅ Node.js detectado: {node_version}")
            else:
                self.log("❌ Node.js no está instalado o no se encuentra en PATH")
                return False

            # Verificar npm
            npm_result = subprocess.run(["npm", "--version"], capture_output=True, text=True, shell=True)
            if npm_result.returncode == 0:
                npm_version = npm_result.stdout.strip()
                self.log(f"✅ npm detectado: {npm_version}")
            else:
                self.log("❌ npm no está instalado o no se encuentra en PATH")
                return False

            return True

        except Exception as e:
            self.log(f"❌ Error verificando prerequisitos: {str(e)}")
            return False

    def setup_ui(self):
        """Configurar la interfaz de usuario"""

        # Título principal
        title_frame = tk.Frame(self.root, bg='#2b2b2b')
        title_frame.pack(pady=10)

        title_label = tk.Label(
            title_frame,
            text="🚀 PANEL DE CONTROL WEB2 - OPTIMIZADO 🚀",
            font=("Arial", 16, "bold"),
            fg="white",
            bg='#2b2b2b'
        )
        title_label.pack()

        # Frame principal con tres columnas
        main_frame = tk.Frame(self.root, bg='#2b2b2b')
        main_frame.pack(padx=20, pady=10, fill=tk.BOTH, expand=True)

        # BACKEND (Columna izquierda)
        backend_frame = tk.LabelFrame(
            main_frame,
            text="🖥️ BACKEND (Puerto 3001)",
            font=("Arial", 12, "bold"),
            fg="white",
            bg='#3b3b3b',
            relief=tk.RAISED,
            bd=2
        )
        backend_frame.pack(side=tk.LEFT, padx=5, pady=10, fill=tk.BOTH, expand=True)

        # Botones Backend
        self.btn_start_backend = tk.Button(
            backend_frame,
            text="🚀 Iniciar Backend",
            command=self.start_backend,
            bg="#28a745",
            fg="white",
            font=("Arial", 10, "bold"),
            padx=20,
            pady=10
        )
        self.btn_start_backend.pack(pady=5, fill=tk.X, padx=10)

        self.btn_stop_backend = tk.Button(
            backend_frame,
            text="🛑 Detener Backend",
            command=self.stop_backend,
            bg="#dc3545",
            fg="white",
            font=("Arial", 10, "bold"),
            padx=20,
            pady=10
        )
        self.btn_stop_backend.pack(pady=5, fill=tk.X, padx=10)

        # Estado Backend
        status_backend_label = tk.Label(
            backend_frame,
            text="Estado:",
            font=("Arial", 10, "bold"),
            fg="white",
            bg='#3b3b3b'
        )
        status_backend_label.pack(pady=5)

        self.status_backend_display = tk.Label(
            backend_frame,
            textvariable=self.backend_status,
            font=("Arial", 12, "bold"),
            fg="white",
            bg='#3b3b3b'
        )
        self.status_backend_display.pack(pady=5)

        # FRONTEND (Columna centro)
        frontend_frame = tk.LabelFrame(
            main_frame,
            text="🎨 FRONTEND (Puerto 5174)",
            font=("Arial", 12, "bold"),
            fg="white",
            bg='#3b3b3b',
            relief=tk.RAISED,
            bd=2
        )
        frontend_frame.pack(side=tk.LEFT, padx=5, pady=10, fill=tk.BOTH, expand=True)

        # Botones Frontend
        self.btn_start_frontend = tk.Button(
            frontend_frame,
            text="🚀 Iniciar Frontend",
            command=self.start_frontend,
            bg="#007bff",
            fg="white",
            font=("Arial", 10, "bold"),
            padx=20,
            pady=10
        )
        self.btn_start_frontend.pack(pady=5, fill=tk.X, padx=10)

        self.btn_stop_frontend = tk.Button(
            frontend_frame,
            text="🛑 Detener Frontend",
            command=self.stop_frontend,
            bg="#dc3545",
            fg="white",
            font=("Arial", 10, "bold"),
            padx=20,
            pady=10
        )
        self.btn_stop_frontend.pack(pady=5, fill=tk.X, padx=10)

        # Estado Frontend
        status_frontend_label = tk.Label(
            frontend_frame,
            text="Estado:",
            font=("Arial", 10, "bold"),
            fg="white",
            bg='#3b3b3b'
        )
        status_frontend_label.pack(pady=5)

        self.status_frontend_display = tk.Label(
            frontend_frame,
            textvariable=self.frontend_status,
            font=("Arial", 12, "bold"),
            fg="white",
            bg='#3b3b3b'
        )
        self.status_frontend_display.pack(pady=5)

        # SISTEMA OCR (Columna derecha)
        ocr_frame = tk.LabelFrame(
            main_frame,
            text="🔍 SISTEMA OCR (Puerto 3002)",
            font=("Arial", 12, "bold"),
            fg="white",
            bg='#3b3b3b',
            relief=tk.RAISED,
            bd=2
        )
        ocr_frame.pack(side=tk.RIGHT, padx=5, pady=10, fill=tk.BOTH, expand=True)

        # Botones OCR
        self.btn_start_ocr = tk.Button(
            ocr_frame,
            text="🚀 Iniciar OCR",
            command=self.start_ocr,
            bg="#6f42c1",
            fg="white",
            font=("Arial", 10, "bold"),
            padx=20,
            pady=10
        )
        self.btn_start_ocr.pack(pady=5, fill=tk.X, padx=10)

        self.btn_stop_ocr = tk.Button(
            ocr_frame,
            text="🛑 Detener OCR",
            command=self.stop_ocr,
            bg="#dc3545",
            fg="white",
            font=("Arial", 10, "bold"),
            padx=20,
            pady=10
        )
        self.btn_stop_ocr.pack(pady=5, fill=tk.X, padx=10)

        # Estado OCR
        status_ocr_label = tk.Label(
            ocr_frame,
            text="Estado:",
            font=("Arial", 10, "bold"),
            fg="white",
            bg='#3b3b3b'
        )
        status_ocr_label.pack(pady=5)

        self.status_ocr_display = tk.Label(
            ocr_frame,
            textvariable=self.ocr_status,
            font=("Arial", 12, "bold"),
            fg="white",
            bg='#3b3b3b'
        )
        self.status_ocr_display.pack(pady=5)

        # Botones de utilidad
        utility_frame = tk.Frame(self.root, bg='#2b2b2b')
        utility_frame.pack(pady=10)

        btn_open_app = tk.Button(
            utility_frame,
            text="🌐 Abrir Aplicación",
            command=self.open_application,
            bg="#ffc107",
            fg="black",
            font=("Arial", 10, "bold"),
            padx=20,
            pady=5
        )
        btn_open_app.pack(side=tk.LEFT, padx=5)

        btn_open_ocr = tk.Button(
            utility_frame,
            text="🔍 Abrir OCR",
            command=self.open_ocr_system,
            bg="#6f42c1",
            fg="white",
            font=("Arial", 10, "bold"),
            padx=20,
            pady=5
        )
        btn_open_ocr.pack(side=tk.LEFT, padx=5)

        btn_restart_all = tk.Button(
            utility_frame,
            text="🔄 Reiniciar Todo",
            command=self.restart_all,
            bg="#17a2b8",
            fg="white",
            font=("Arial", 10, "bold"),
            padx=20,
            pady=5
        )
        btn_restart_all.pack(side=tk.LEFT, padx=5)

        btn_help = tk.Button(
            utility_frame,
            text="ℹ️ Ayuda",
            command=self.show_help,
            bg="#6c757d",
            fg="white",
            font=("Arial", 10, "bold"),
            padx=20,
            pady=5
        )
        btn_help.pack(side=tk.LEFT, padx=5)

        # Log de eventos
        log_frame = tk.LabelFrame(
            self.root,
            text="📋 Log de Eventos",
            font=("Arial", 10, "bold"),
            fg="white",
            bg='#2b2b2b',
            relief=tk.RAISED,
            bd=2
        )
        log_frame.pack(padx=20, pady=10, fill=tk.BOTH, expand=True)

        self.log_text = scrolledtext.ScrolledText(
            log_frame,
            height=8,
            bg='#1e1e1e',
            fg='#00ff00',
            font=("Consolas", 9),
            insertbackground='white'
        )
        self.log_text.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        # Botón salir
        btn_exit = tk.Button(
            self.root,
            text="❌ Salir",
            command=self.exit_application,
            bg="#dc3545",
            fg="white",
            font=("Arial", 10, "bold"),
            padx=20,
            pady=5
        )
        btn_exit.pack(pady=10)

        # Log inicial
        self.log("🎉 Panel de Control WEB2 Optimizado iniciado")
        self.log(f"📁 Ruta del proyecto: {self.project_path}")

    def log(self, message):
        """Agregar mensaje al log"""
        try:
            timestamp = datetime.now().strftime("%H:%M:%S")
            # Asegurarse de que el mensaje sea una cadena válida
            if isinstance(message, bytes):
                message = message.decode('utf-8', errors='ignore')
            elif not isinstance(message, str):
                message = str(message)

            log_message = f"[{timestamp}] {message}\n"
            self.log_text.insert(tk.END, log_message)
            self.log_text.see(tk.END)
        except Exception as e:
            # En caso de error, intentar log básico
            try:
                timestamp = datetime.now().strftime("%H:%M:%S")
                basic_message = f"[{timestamp}] Error en log: {str(e)}\n"
                self.log_text.insert(tk.END, basic_message)
                self.log_text.see(tk.END)
            except:
                pass

    def start_backend(self):
        """Iniciar el servidor backend"""
        # Verificar si ya está corriendo
        if self.check_port(3001):
            self.log("⚠️ Backend ya está corriendo en puerto 3001")
            return

        try:
            self.log("🚀 Iniciando backend...")

            # Verificar que existe server.js
            server_path = os.path.join(self.project_path, "server.js")
            if not os.path.exists(server_path):
                self.log(f"❌ No se encontró server.js en {server_path}")
                return

            # Cambiar al directorio del proyecto
            os.chdir(self.project_path)

            # Iniciar proceso backend sin capturar output para evitar problemas de codificación
            self.backend_process = subprocess.Popen(
                ["node", "server.js"],
                cwd=self.project_path,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
            )

            self.log(f"✅ Backend iniciado (PID: {self.backend_process.pid})")

            # Verificar que el backend se inicie correctamente
            threading.Thread(target=self.verify_backend_startup, daemon=True).start()

        except FileNotFoundError:
            self.log("❌ Error: Node.js no está instalado o no se encuentra en PATH")
        except Exception as e:
            self.log(f"❌ Error al iniciar backend: {str(e)}")

    def verify_backend_startup(self):
        """Verificar que el backend se inicie correctamente"""
        for i in range(30):  # Intentar por 30 segundos
            time.sleep(1)
            if self.check_port(3001):
                self.log("🎯 Backend confirmado listo en puerto 3001")
                return
        self.log("⚠️ Backend no respondió en puerto 3001 después de 30 segundos")

    def start_frontend(self):
        """Iniciar el servidor frontend"""
        # Verificar si ya está corriendo
        if self.check_port(5174):
            self.log("⚠️ Frontend ya está corriendo en puerto 5174")
            return

        try:
            self.log("🚀 Iniciando frontend...")

            # Verificar que existe el directorio dashboard
            if not os.path.exists(self.dashboard_path):
                self.log(f"❌ No se encontró directorio dashboard en {self.dashboard_path}")
                return

            # Verificar que existe package.json
            package_json_path = os.path.join(self.dashboard_path, "package.json")
            if not os.path.exists(package_json_path):
                self.log(f"❌ No se encontró package.json en {package_json_path}")
                return

            # Cambiar al directorio dashboard
            os.chdir(self.dashboard_path)

            # Iniciar proceso frontend sin capturar output para evitar problemas de codificación
            self.frontend_process = subprocess.Popen(
                ["npm", "run", "dev"],
                cwd=self.dashboard_path,
                shell=True,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
            )

            self.log(f"✅ Frontend iniciado (PID: {self.frontend_process.pid})")

            # Verificar que el frontend se inicie correctamente
            threading.Thread(target=self.verify_frontend_startup, daemon=True).start()

        except FileNotFoundError:
            self.log("❌ Error: npm no está instalado o no se encuentra en PATH")
        except Exception as e:
            self.log(f"❌ Error al iniciar frontend: {str(e)}")

    def verify_frontend_startup(self):
        """Verificar que el frontend se inicie correctamente"""
        for i in range(60):  # Intentar por 60 segundos (Vite puede tardar más)
            time.sleep(1)
            if self.check_port(5174):
                self.log("🎯 Frontend confirmado listo en puerto 5174")
                return
        self.log("⚠️ Frontend no respondió en puerto 5174 después de 60 segundos")

    def stop_backend(self):
        """Detener el servidor backend"""
        try:
            self.log("🛑 Deteniendo backend...")

            # Buscar y terminar procesos de Node.js que ejecuten server.js
            killed_any = False
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if proc.info['name'] == 'node.exe':
                        cmdline = ' '.join(proc.info['cmdline']) if proc.info['cmdline'] else ''
                        if 'server.js' in cmdline:
                            proc.terminate()
                            killed_any = True
                            self.log(f"🔄 Terminando proceso Node.js (PID: {proc.pid})")
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            # Si tenemos referencia al proceso, también intentar terminarlo
            if self.backend_process:
                try:
                    if isinstance(self.backend_process, subprocess.Popen):
                        self.backend_process.terminate()
                    elif hasattr(self.backend_process, 'terminate'):
                        self.backend_process.terminate()
                    killed_any = True
                except:
                    pass

            self.backend_process = None

            if killed_any:
                self.log("✅ Backend detenido correctamente")
            else:
                self.log("⚠️ No se encontraron procesos backend ejecutándose")

        except Exception as e:
            self.log(f"❌ Error al detener backend: {str(e)}")

    def stop_frontend(self):
        """Detener el servidor frontend"""
        try:
            self.log("🛑 Deteniendo frontend...")

            # Buscar y terminar procesos npm/vite relacionados con dashboard
            killed_any = False
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if proc.info['name'] in ['node.exe', 'npm.cmd']:
                        cmdline = ' '.join(proc.info['cmdline']) if proc.info['cmdline'] else ''
                        if ('vite' in cmdline or 'npm run dev' in cmdline) and 'dashboard' in cmdline:
                            # Terminar proceso y sus hijos
                            try:
                                parent = psutil.Process(proc.pid)
                                children = parent.children(recursive=True)
                                for child in children:
                                    child.terminate()
                                parent.terminate()
                                killed_any = True
                                self.log(f"🔄 Terminando proceso frontend (PID: {proc.pid})")
                            except:
                                pass
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            # Si tenemos referencia al proceso, también intentar terminarlo
            if self.frontend_process:
                try:
                    if isinstance(self.frontend_process, subprocess.Popen):
                        self.frontend_process.terminate()
                    elif hasattr(self.frontend_process, 'terminate'):
                        self.frontend_process.terminate()
                    killed_any = True
                except:
                    pass

            self.frontend_process = None

            if killed_any:
                self.log("✅ Frontend detenido correctamente")
            else:
                self.log("⚠️ No se encontraron procesos frontend ejecutándose")

        except Exception as e:
            self.log(f"❌ Error al detener frontend: {str(e)}")

    def start_ocr(self):
        """Iniciar el servidor OCR"""
        # Verificar si ya está corriendo
        if self.check_port(3002):
            self.log("⚠️ Sistema OCR ya está corriendo en puerto 3002")
            return

        try:
            self.log("🚀 Iniciando sistema OCR...")

            # Verificar que existe el directorio ocr-system
            if not os.path.exists(self.ocr_path):
                self.log(f"❌ No se encontró directorio ocr-system en {self.ocr_path}")
                return

            # Verificar que existe server.js
            server_js_path = os.path.join(self.ocr_path, "server.js")
            if not os.path.exists(server_js_path):
                self.log(f"❌ No se encontró server.js en {server_js_path}")
                return

            # Cambiar al directorio OCR
            os.chdir(self.ocr_path)

            # Crear proceso
            self.ocr_process = subprocess.Popen(
                ["node", "server.js"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
                cwd=self.ocr_path
            )

            self.log("🔄 Esperando a que OCR inicie...")

            # Verificar que inició correctamente
            for i in range(30):  # Esperar hasta 30 segundos
                if self.check_port(3002):
                    self.log("✅ Sistema OCR iniciado correctamente en puerto 3002")

                    # Iniciar monitoreo de output
                    threading.Thread(target=self.monitor_ocr_output, daemon=True).start()
                    return

                time.sleep(1)

            self.log("⚠️ Sistema OCR no respondió en puerto 3002 después de 30 segundos")

        except Exception as e:
            self.log(f"❌ Error al iniciar sistema OCR: {str(e)}")
            self.ocr_process = None

    def stop_ocr(self):
        """Detener el servidor OCR"""
        try:
            self.log("🛑 Deteniendo sistema OCR...")

            # Primero intentar terminar procesos por puerto
            killed_any = False

            # Buscar procesos en puerto 3002
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if proc.info['cmdline']:
                        cmdline = ' '.join(proc.info['cmdline'])
                        if ('node' in cmdline and 'server.js' in cmdline and 'ocr-system' in cmdline) or \
                           (proc.info['name'] == 'node.exe' and any('ocr-system' in arg for arg in proc.info['cmdline'])):
                            proc.terminate()
                            killed_any = True
                            self.log(f"🔄 Terminando proceso OCR PID: {proc.info['pid']}")
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass

            # También intentar con nuestro proceso guardado
            if self.ocr_process:
                try:
                    if isinstance(self.ocr_process, subprocess.Popen):
                        self.ocr_process.terminate()
                    elif hasattr(self.ocr_process, 'terminate'):
                        self.ocr_process.terminate()
                    killed_any = True
                except:
                    pass

            self.ocr_process = None

            if killed_any:
                self.log("✅ Sistema OCR detenido correctamente")
            else:
                self.log("⚠️ No se encontraron procesos OCR ejecutándose")

        except Exception as e:
            self.log(f"❌ Error al detener sistema OCR: {str(e)}")

    def monitor_ocr_output(self):
        """Monitorear output del sistema OCR"""
        if not self.ocr_process:
            return

        try:
            while True:
                try:
                    line = self.ocr_process.stdout.readline()
                    if not line:
                        break

                    line = line.strip()
                    if line:
                        line_lower = line.lower()
                        if any(keyword in line_lower for keyword in ["puerto 3002", "port 3002", "listening on", "servidor ocr corriendo"]):
                            self.log("🎯 Sistema OCR listo en puerto 3002")
                        elif any(keyword in line_lower for keyword in ["error", "failed", "exception"]):
                            self.log(f"❌ OCR Error: {line}")
                        elif "worker" in line_lower or "tesseract" in line_lower:
                            self.log(f"🔍 OCR: {line}")
                        elif "inicializando" in line_lower or "inicializado" in line_lower:
                            self.log(f"📡 OCR: {line}")

                except UnicodeDecodeError as e:
                    # Ignorar errores de codificación específicos
                    continue
                except Exception as e:
                    self.log(f"⚠️ Error leyendo output del OCR: {str(e)}")
                    break

        except Exception as e:
            self.log(f"⚠️ Error monitoreando backend: {str(e)}")

    def monitor_frontend_output(self):
        """Monitorear output del frontend"""
        if not self.frontend_process:
            return

        try:
            while True:
                try:
                    line = self.frontend_process.stdout.readline()
                    if not line:
                        break

                    line = line.strip()
                    if line:
                        line_lower = line.lower()
                        if any(keyword in line_lower for keyword in ["localhost:5174", "port 5174", "local:", "dev server running"]):
                            self.log("🎯 Frontend listo en puerto 5174")
                        elif any(keyword in line_lower for keyword in ["error", "failed", "exception"]):
                            self.log(f"❌ Frontend Error: {line}")
                        elif "ready" in line_lower or "compiled" in line_lower:
                            self.log(f"📦 Frontend: {line}")

                except UnicodeDecodeError as e:
                    # Ignorar errores de codificación específicos
                    continue
                except Exception as e:
                    self.log(f"⚠️ Error leyendo output del frontend: {str(e)}")
                    break

        except Exception as e:
            self.log(f"⚠️ Error monitoreando frontend: {str(e)}")

    def check_port(self, port):
        """Verificar si un puerto está en uso"""
        try:
            import socket
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            result = sock.connect_ex(('localhost', port))
            sock.close()

            if result == 0:
                return True

            # Fallback: intentar hacer request HTTP
            try:
                response = requests.get(f"http://localhost:{port}", timeout=3)
                return response.status_code < 500
            except requests.exceptions.ConnectTimeout:
                return False
            except requests.exceptions.ConnectionError:
                return False
            except:
                return False

        except Exception:
            return False

    def start_monitoring(self):
        """Iniciar monitoreo de estado"""
        def monitor():
            while True:
                try:
                    # Verificar backend
                    backend_running = self.check_port(3001)
                    if backend_running:
                        self.backend_status.set("🟢 Corriendo")
                    else:
                        self.backend_status.set("🔴 Detenido")

                    # Verificar frontend
                    frontend_running = self.check_port(5174)
                    if frontend_running:
                        self.frontend_status.set("🟢 Corriendo")
                    else:
                        self.frontend_status.set("🔴 Detenido")

                    # Verificar sistema OCR
                    ocr_running = self.check_port(3002)
                    if ocr_running:
                        self.ocr_status.set("🟢 Corriendo")
                    else:
                        self.ocr_status.set("🔴 Detenido")

                    # Verificar si los procesos siguen activos
                    if self.backend_process and hasattr(self.backend_process, 'poll'):
                        if self.backend_process.poll() is not None:
                            self.backend_process = None

                    if self.frontend_process and hasattr(self.frontend_process, 'poll'):
                        if self.frontend_process.poll() is not None:
                            self.frontend_process = None

                    if self.ocr_process and hasattr(self.ocr_process, 'poll'):
                        if self.ocr_process.poll() is not None:
                            self.ocr_process = None

                except Exception as e:
                    # En caso de error, continuar monitoreando
                    pass

                time.sleep(3)

        threading.Thread(target=monitor, daemon=True).start()

    def open_application(self):
        """Abrir la aplicación en el navegador"""
        self.log("🌐 Abriendo aplicación en el navegador...")

        # Verificar primero con socket directo
        try:
            import socket
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            result = sock.connect_ex(('localhost', 5174))
            sock.close()

            if result == 0:
                # Puerto disponible, abrir navegador
                webbrowser.open("http://localhost:5174")
                self.log("✅ Aplicación abierta en el navegador")
                return
            else:
                self.log("⚠️ No se puede conectar al puerto 5174")
        except Exception as e:
            self.log(f"⚠️ Error verificando puerto: {str(e)}")

        # Si llegamos aquí, mostrar advertencia pero intentar abrir de todas formas
        self.log("⚠️ Intentando abrir de todas formas...")
        webbrowser.open("http://localhost:5174")

        messagebox.showinfo(
            "Información",
            "Se está intentando abrir la aplicación.\n\n"
            "Si no se abre correctamente, verifica que:\n"
            "1. El frontend esté corriendo\n"
            "2. Ve a http://localhost:5174 manualmente"
        )

    def open_ocr_system(self):
        """Abrir el sistema OCR en el navegador"""
        self.log("🔍 Abriendo sistema OCR en el navegador...")

        # Verificar primero con socket directo
        try:
            import socket
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            result = sock.connect_ex(('localhost', 3002))
            sock.close()

            if result == 0:
                # Puerto disponible, abrir navegador
                webbrowser.open("http://localhost:3002")
                self.log("✅ Sistema OCR abierto en el navegador")
                return
            else:
                self.log("⚠️ No se puede conectar al puerto 3002")
        except Exception as e:
            self.log(f"⚠️ Error verificando puerto OCR: {str(e)}")

        # Si llegamos aquí, mostrar advertencia pero intentar abrir de todas formas
        self.log("⚠️ Intentando abrir sistema OCR de todas formas...")
        webbrowser.open("http://localhost:3002")

        messagebox.showinfo(
            "Información",
            "Se está intentando abrir el sistema OCR.\n\n"
            "Si no se abre correctamente, verifica que:\n"
            "1. El sistema OCR esté corriendo\n"
            "2. Ve a http://localhost:3002 manualmente"
        )

    def restart_all(self):
        """Reiniciar todos los servicios"""
        self.log("🔄 Reiniciando todos los servicios...")

        # Detener todos
        self.stop_backend()
        self.stop_frontend()
        self.stop_ocr()

        # Esperar un momento
        time.sleep(2)

        # Iniciar todos
        self.start_backend()
        time.sleep(3)  # Esperar que backend esté listo
        self.start_frontend()
        time.sleep(2)  # Esperar un poco
        self.start_ocr()

    def show_help(self):
        """Mostrar ayuda"""
        help_text = """
🚀 AYUDA - Panel de Control WEB2 Optimizado

📋 INSTRUCCIONES:
1. Haz clic en "🚀 Iniciar Backend" para iniciar el servidor (Puerto 3001)
2. Espera a que aparezca "Backend confirmado listo en puerto 3001"
3. Haz clic en "🚀 Iniciar Frontend" para iniciar la interfaz (Puerto 5174)
4. Espera a que aparezca "Frontend confirmado listo en puerto 5174"
5. Haz clic en "🚀 Iniciar OCR" para el sistema de documentos (Puerto 3002)
6. Usa "🌐 Abrir Aplicación" o "🔍 Abrir OCR" según necesites

🔧 SOLUCIÓN DE PROBLEMAS:
- Si un servicio no inicia, usa "🔄 Reiniciar Todo"
- Verifica que Node.js esté instalado
- Verifica que npm esté instalado
- Los puertos 3001, 3002 y 5174 deben estar libres

🌐 URLS IMPORTANTES:
- Aplicación Principal: http://localhost:5174
- API Backend: http://localhost:3001
- Sistema OCR: http://localhost:3002
- Health Check: http://localhost:3001/health

⚠️ NOTA:
- Siempre inicia el Backend ANTES que el Frontend
- El sistema OCR es independiente y puede iniciarse en cualquier momento
- No cierres esta ventana mientras uses las aplicaciones
- Esta versión optimizada evita problemas de codificación
        """

        messagebox.showinfo("Ayuda", help_text)

    def exit_application(self):
        """Salir de la aplicación"""
        if messagebox.askyesno("Salir", "¿Deseas detener todos los servicios y salir?"):
            self.log("🛑 Deteniendo todos los servicios antes de salir...")
            self.stop_backend()
            self.stop_frontend()
            self.stop_ocr()
            time.sleep(1)
            self.root.quit()

def main():
    """Función principal"""
    root = tk.Tk()
    app = PanelControlWEB2(root)

    # Configurar evento de cierre de ventana
    root.protocol("WM_DELETE_WINDOW", app.exit_application)

    # Iniciar aplicación
    root.mainloop()

if __name__ == "__main__":
    main()
